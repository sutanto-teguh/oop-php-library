# 📘 Membuat Library Sederhana Berbasis OOP Menggunakan PHP

**Penulis:** Teguh Sutanto, M.Kom.  
**Tahun:** 2025  

## 📖 Deskripsi
Proyek ini merupakan contoh implementasi **konsep Object-Oriented Programming (OOP)** menggunakan bahasa pemrograman PHP.  
Tujuan utama repository ini adalah memberikan contoh praktis pembuatan **library sederhana** yang mendukung proses *CRUD (Create, Read, Update, Delete)* baik berbasis file JSON maupun database MySQL.  

## 🧩 Fitur Utama
- Penerapan konsep **Class**, **Encapsulation**, dan **Namespace** dalam PHP  
- Contoh *library* sederhana untuk operasi matematika (`Calculator`)  
- Contoh *utility* format data (`Formatter`)  
- CRUD sederhana berbasis file JSON (`BarangRepository`)  
- CRUD berbasis database MySQL (`BarangRepositoryDB`)  

## 🏗️ Struktur Folder
```
oop-php-library/
│
├── src/
│   ├── Entity/Barang.php
│   ├── Repository/
│   │   ├── BarangRepository.php
│   │   └── BarangRepositoryDB.php
│   ├── Math/Calculator.php
│   ├── Utils/Formatter.php
│   └── config/database.php
├── data/barang.json
├── index.php
├── index-db.php
├── .gitignore
└── README.md
```

## ⚙️ Instalasi
1. Clone repository ini:  
   ```bash
   git clone https://github.com/username/oop-php-library.git
   cd oop-php-library
   ```
2. Pastikan PHP sudah terpasang di sistem Anda (`php -v`).  
3. Jalankan contoh sederhana:  
   ```bash
   php index.php
   ```
4. Untuk contoh database, sesuaikan konfigurasi pada `src/config/database.php`, lalu jalankan:  
   ```bash
   php index-db.php
   ```

## 🧠 Contoh Penggunaan
```php
require_once 'src/Entity/Barang.php';
require_once 'src/Repository/BarangRepository.php';

use Library\Entity\Barang;
use Library\Repository\BarangRepository;

$repo = new BarangRepository('data/barang.json');
$repo->create(new Barang('Pulpen', 3000, 20));

print_r($repo->readAll());
```

## 📂 Lisensi
Proyek ini menggunakan lisensi **MIT License** — Anda bebas menggunakan, menyalin, dan memodifikasi dengan mencantumkan kredit kepada penulis.  
